package main

import (
	"bytes"
	"compress/zlib"
	"crypto/aes"
	"crypto/cipher"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"io"
	"log"
	"math/big"
	"os"
	"time"

	"errors"

	"image"
	"image/draw"
	"image/jpeg"

	"math"
	"strconv"

	"github.com/fxamacker/cbor/v2"
	"github.com/gofiber/fiber/v2"
	"github.com/h2non/bimg"
	"gopkg.in/square/go-jose.v2"

	// "github.com/ldclabs/cose/cose"
	// "github.com/ldclabs/cose/cwt"

	// edcose "github.com/ldclabs/cose/key/ed25519"

	"github.com/nfnt/resize"
	"github.com/skip2/go-qrcode"
	qr "github.com/tuotoo/qrcode"
)

type VCClaims struct {
	RequestId           string `json:"RequestId"`
	PanNumber           string `json:"PanNumber"`
	CardType            string `json:"CardType"`
	NameOnCard          string `json:"NameOnCard"`
	ParentName          string `json:"ParentName"`
	ParentLabel         string `json:"ParentLabel"`
	DateOfBirth         string `json:"DateOfBirth"`
	DateOfIncorporation string `json:"DateOfIncorporation,omitempty"`
	Photo               string `json:"Photo"`
	SignaturePhoto      string `json:"SignaturePhoto"`
	PhotoEncoding       string `json:"PhotoEncoding"`
}

type CustomClaims struct {
	PIData string
	Photo  []byte
}

type CustomClaimsNI struct {
	PIData string
}

type CombinedClaims struct {
	Issuer     string       `cbor:"iss"` // Standard claim
	Subject    string       `cbor:"sub"` // Standard claim
	Audience   string       `cbor:"aud"` // Standard claim
	Expiration uint64       `cbor:"exp"` // Standard claim
	CWTID      []byte       `cbor:"cti"` // Standard claim
	Custom     CustomClaims `cbor:"custom"`
}

type CombinedClaimsNI struct {
	Issuer     string         `cbor:"iss"` // Standard claim
	Subject    string         `cbor:"sub"` // Standard claim
	Audience   string         `cbor:"aud"` // Standard claim
	Expiration uint64         `cbor:"exp"` // Standard claim
	CWTID      []byte         `cbor:"cti"` // Standard claim
	Custom     CustomClaimsNI `cbor:"custom"`
}

var Public_Key, _ = base64.StdEncoding.DecodeString("xTfpXbxIdYxIgDtCou2kym1gE8pVeaSzPpGLaYFm8AA=")
var Private_key, _ = base64.StdEncoding.DecodeString("nfKGaluedn32SPTE+dP9oO83xRzcbE3HdjOSAStuKhrFN+ldvEh1jEiAO0Ki7aTKbWATylV5pLM+kYtpgWbwAA==")

func init() {
	// Open (or create) the log file in append mode
	logFile, err := os.OpenFile("app.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
	if err != nil {
		log.Fatalf("Failed to open log file: %v", err)
	}

	// Set log output to the file
	log.SetOutput(logFile)

	// Configure the log format
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)
	log.Println("Application starting...")
}

func hexToBinary(hexString string) ([]byte, error) {
	log.Println("Converting hex string to binary")
	length := len(hexString)
	if length%2 != 0 {
		return nil, errors.New("invalid hexadecimal string length (must be even)")
	}

	binaryBytes := make([]byte, length/2)
	for i := 0; i < length; i += 2 {
		intValue, err := strconv.ParseUint(hexString[i:i+2], 16, 8)
		if err != nil {
			return nil, fmt.Errorf("invalid hexadecimal chunk: %w", err)
		}
		binaryBytes[i/2] = byte(intValue)
	}
	return binaryBytes, nil
}
func decodeImageFromBinary(data []byte) (image.Image, error) {
	log.Println("Decoding image from binary data")
	img, _, err := image.Decode(bytes.NewReader(data))
	if err != nil {
		return nil, fmt.Errorf("error decoding image: %w", err)
	}
	return img, nil
}

// test 3
func combineImagesBinary(photoBinary, signatureBinary []byte) ([]byte, error) {
	log.Println("Combining photo and signature images")
	photoImg, err := decodeImageFromBinary(photoBinary)
	if err != nil {
		return nil, fmt.Errorf("error decoding photo image: %w", err)
	}

	signatureImg, err := decodeImageFromBinary(signatureBinary)
	if err != nil {
		return nil, fmt.Errorf("error decoding signature image: %w", err)
	}

	combinedWidth := int(math.Min(float64(photoImg.Bounds().Dx()), float64(signatureImg.Bounds().Dx())))
	newSignatureImg := resize.Resize(uint(combinedWidth), 0, signatureImg, resize.Lanczos3)
	combinedHeight := photoImg.Bounds().Dy() + newSignatureImg.Bounds().Dy()

	log.Printf("combinedWidth : ", combinedWidth)
	log.Printf("combinedHeight : ", combinedHeight)

	combinedImage := image.NewRGBA(image.Rect(0, 0, combinedWidth, combinedHeight))

	draw.Draw(combinedImage, photoImg.Bounds(), photoImg, image.Point{}, draw.Over)

	// Draw resized signature image below the photo
	bottomRect := newSignatureImg.Bounds().Add(image.Pt(0, photoImg.Bounds().Dy()))
	draw.Draw(combinedImage, bottomRect, newSignatureImg, image.Point{}, draw.Over)

	// Encode the combined image to JPEG data
	var buf bytes.Buffer
	err = jpeg.Encode(&buf, combinedImage, &jpeg.Options{
		Quality: 95, // Set the quality for better compression
	})
	if err != nil {
		return nil, fmt.Errorf("error encoding combined image to JPEG: %w", err)
	}

	log.Printf("Combined image size: %d bytes", buf.Len())

	return buf.Bytes(), nil
}

func resizeImage(imageData []byte) ([]byte, error) {
	log.Println("Resizing image")
	img, _, err := image.Decode(bytes.NewReader(imageData))
	if err != nil {
		return nil, fmt.Errorf("Error decoding image: %w", err)
	}

	newWidth := uint(img.Bounds().Dx() / 6)
	newHeight := uint(img.Bounds().Dy() / 6)
	resizedImage := resize.Resize(newWidth, newHeight, img, resize.MitchellNetravali)
	// resizedImage := resize.Resize(newWidth, newHeight, img, resize.Lanczos3)

	var buffer bytes.Buffer
	// Reduce JPEG quality to make the image smaller (e.g., 80 quality)
	err = jpeg.Encode(&buffer, resizedImage, &jpeg.Options{Quality: 50})
	if err != nil {
		return nil, fmt.Errorf("Error encoding image: %w", err)
	}

	return buffer.Bytes(), nil
}

func GenerateKeyPair() ([]byte, []byte) {

	publicKey, privateKey, _ := ed25519.GenerateKey(rand.Reader)

	return publicKey, privateKey

}
func encodeToCBOR(data interface{}) ([]byte, error) {
	log.Println("Encoding data to CBOR")
	cborData, err := cbor.Marshal(data)
	if err != nil {
		return nil, fmt.Errorf("failed to encode to CBOR: %v", err)
	}
	log.Println("CBOR Encoded Data Size: ", len(cborData))
	return cborData, nil
}

func signData(privateKey ed25519.PrivateKey, message []byte) []byte {
	log.Println("Signing data")
	signature := ed25519.Sign(privateKey, message)
	log.Println("Signature Size: ", len(signature))
	signedData := append(message, signature...)

	log.Println("Signed Signature Size: ", len(signedData))
	return signedData
}

func verifySignature(publicKey ed25519.PublicKey, message, signature []byte) bool {
	log.Println("Verifying signature")
	return ed25519.Verify(publicKey, message, signature)
}

func Compress(data []byte) ([]byte, error) {
	log.Println("Compressing data")
	var b bytes.Buffer
	writer := zlib.NewWriter(&b)
	_, err := writer.Write(data)
	if err != nil {
		return nil, err
	}
	// Close the writer to flush any remaining data
	err = writer.Close()
	if err != nil {
		return nil, err
	}
	log.Printf("Compressed data size: %d bytes", b.Len())
	return b.Bytes(), nil
}

func decodeImageFromBytes(data []byte) (image.Image, error) {
	reader := bytes.NewReader(data)
	img, _, err := image.Decode(reader)
	if err != nil {
		return nil, fmt.Errorf("error decoding image: %w", err)
	}
	return img, nil
}

func encodeImageToBytes(img image.Image) ([]byte, error) {
	buffer := new(bytes.Buffer)
	err := jpeg.Encode(buffer, img, nil)
	if err != nil {
		return nil, fmt.Errorf("error encoding image to bytes: %w", err)
	}
	return buffer.Bytes(), nil
}

func combineImageBytes(picData, signData []byte) ([]byte, error) {
	img1, err := decodeImageFromBytes(picData)
	if err != nil {
		return nil, fmt.Errorf("error decoding image1: %w", err)
	}

	img2, err := decodeImageFromBytes(signData)
	if err != nil {
		return nil, fmt.Errorf("error decoding image2: %w", err)
	}

	log.Println("Image 1 : ", img1.Bounds().Dx())
	log.Println("Image 2 : ", img2.Bounds().Dx())

	// Combine images side by side
	combinedWidth := min(img1.Bounds().Dx(), img2.Bounds().Dx())

	log.Println("combinedWidth : ", combinedWidth)

	//newImg := resize.Resize(uint(combinedWidth), 0, img2, resize.Lanczos3)
	// Resize signature image's width to pic's width
	// if img1.Bounds().Dx() > img2.Bounds().Dx() {
	//      newImg = resize.Resize(uint(combinedWidth), 0, img1, resize.Lanczos3)
	// }

	resizedImage := resize.Resize(uint(combinedWidth), 0, img2, resize.Lanczos3)

	if img1.Bounds().Dx() < img2.Bounds().Dx() {

		newImg := resize.Resize(uint(combinedWidth), 0, img2, resize.Lanczos3)

		combinedHeight := img1.Bounds().Dy() + newImg.Bounds().Dy()
		combinedImage := image.NewRGBA(image.Rect(0, 0, combinedWidth, combinedHeight))

		// Draw img1 onto the combined image
		draw.Draw(combinedImage, img1.Bounds(), img1, image.Point{}, draw.Over)

		// Draw img2 onto the combined image
		bottomRect := newImg.Bounds().Add(image.Pt(0, img1.Bounds().Dy()))
		draw.Draw(combinedImage, bottomRect, newImg, image.Point{}, draw.Over)

		// Resize the combined image
		newWidth := uint(combinedWidth)
		newHeight := uint(combinedHeight)
		resizedImage = resize.Resize(newWidth, newHeight, combinedImage, resize.Lanczos3)

		// Convert combined image to bytes
		//return encodeImageToBytes(resizedImage)
	}
	if img1.Bounds().Dx() > img2.Bounds().Dx() {

		newImg := resize.Resize(uint(combinedWidth), 0, img1, resize.Lanczos3)

		combinedHeight := newImg.Bounds().Dy() + img2.Bounds().Dy()
		combinedImage := image.NewRGBA(image.Rect(0, 0, combinedWidth, combinedHeight))

		// Draw img1 onto the combined image
		draw.Draw(combinedImage, newImg.Bounds(), newImg, image.Point{}, draw.Over)

		// Draw img2 onto the combined image
		bottomRect := img2.Bounds().Add(image.Pt(0, newImg.Bounds().Dy()))
		draw.Draw(combinedImage, bottomRect, img2, image.Point{}, draw.Over)

		// Resize the combined image
		newWidth := uint(combinedWidth)
		newHeight := uint(combinedHeight)
		resizedImage = resize.Resize(newWidth, newHeight, combinedImage, resize.Lanczos3)

		// Convert combined image to bytes
		//return encodeImageToBytes(resizedImage)
	}

	return encodeImageToBytes(resizedImage)
}

func sharpenAndCompressImage(imageData []byte) ([]byte, error) {
	options := bimg.Options{
		Sharpen: bimg.Sharpen{
			M1:     -10.0,
			M2:     -4.0,
			X1:     -4.0,
			Y2:     -20.0,
			Radius: -2.0,
		},
		Width:         75,
		Height:        95,
		Quality:       50,
		Brightness:    2,
		Type:          bimg.WEBP,
		StripMetadata: true,
	}

	return bimg.NewImage(imageData).Process(options)
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

var whitespace = "ffd8ffe000104a46494600010200000100010000ffdb004300080606070605080707070909080a0c140d0c0b0b0c1912130f141d1a1f1e1d1a1c1c20242e2720222c231c1c2837292c30313434341f27393d38323c2e333432ffdb0043010909090c0b0c180d0d1832211c213232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232ffc000110800cc00cc03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00f7fa28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2800a28a2803fffd931312e3731313132333435363738393734313235"

func GenerateQRCode(data VCClaims) (string, error) {
	log.Println("Generating QR code for Request ID - ", data.RequestId)

	if data.CardType == "NI" {
		fmt.Println("NI detected")
		piData := data.PanNumber + "|" + data.CardType + "|" + data.NameOnCard + "|" + data.ParentName + "|" + data.ParentLabel + "|" + data.DateOfBirth + "|" + data.DateOfIncorporation

		base64Str := "SMgkSg8q/62WI0IZ8xCM2w=="

		// Decode the Base64 string
		decodedBytes, err := base64.StdEncoding.DecodeString(base64Str)
		fmt.Println(decodedBytes)

		nonce, encryptedPIData, err := encrypt([]byte(piData), decodedBytes)
		if err != nil {
			return "", fmt.Errorf("failed to encrypt PIData: %v", err)
		}

		cwtClaims := CombinedClaimsNI{
			Issuer:     "VC-Issuer",
			Subject:    "Test Resident",
			Audience:   "VC-Holder",
			Expiration: uint64(time.Now().Add(time.Hour * 24).Unix()),
			CWTID:      []byte{1, 2, 3, 4},
			Custom: CustomClaimsNI{
				PIData: base64.StdEncoding.EncodeToString(append(nonce, encryptedPIData...)), //base64.StdEncoding.EncodeToString(append(nonce, encryptedPIData...)),
			},
		}

		//Encode payload to CBOR
		cborPayload, err := cbor.Marshal(cwtClaims)
		if err != nil {
			log.Fatalf("Failed to CBOR encode payload: %v", err)
		}

		log.Println("cborPayload : ", len(cborPayload))

		// Create a signing key
		key := []byte("my-secret-key-12345") // Replace with your secure key
		signingKey := jose.SigningKey{Algorithm: jose.HS256, Key: key}

		// Create a signer
		signer, err := jose.NewSigner(signingKey, nil)
		if err != nil {
			log.Fatalf("Failed to create signer: %v", err)
		}

		// Create CWT (sign CBOR payload)
		object, err := signer.Sign(cborPayload)
		if err != nil {
			log.Fatalf("Failed to sign payload: %v", err)
		}

		// Serialize the signed object
		compactSerialization, err := object.CompactSerialize()
		if err != nil {
			log.Fatalf("Failed to serialize signed object: %v", err)
		}

		//fmt.Println("CWT Token:", compactSerialization)

		qrCode, err := qrcode.New("CBOR"+compactSerialization, qrcode.High)
		if err != nil {
			return "", fmt.Errorf("failed to create QR code: %v", err)
		}

		//log.Println("qrcode value --", qrCode)

		qrCodeData, err := qrCode.PNG(260)
		if err != nil {
			return "", fmt.Errorf("failed to generate PNG QR code: %v", err)
		}

		qrBase64 := base64.StdEncoding.EncodeToString(qrCodeData)

		return qrBase64, nil

	} else {

		fmt.Println("I detected")

		var combinedImageData []byte
		var err error
		photoBinary, _ := hexToBinary(data.Photo)
		check_photo, err := decodeImageFromBinary(photoBinary)
		if err != nil {
			return "", fmt.Errorf("E201 - Invalid Photo contents sent in request (bad Base64 or Hex value)")
		}
		fmt.Println("photo binary - ", check_photo)
		if data.SignaturePhoto != whitespace {
			signatureBinary, _ := hexToBinary(data.SignaturePhoto)
			check_signature, err := decodeImageFromBinary(signatureBinary)
			if err != nil {
				return "", fmt.Errorf("E202 - Invalid Signature contents sent in request (bad Base64 or Hex value)")
			}
			fmt.Println("photo binary - ", check_signature)
			combinedImageData, err = combineImageBytes(photoBinary, signatureBinary)
		} else {
			fmt.Println("i am here")
			combinedImageData = photoBinary // If no signature, just use the photo
		}

		// combinedBinary, err := combineImagesBinary(photoBinary, signatureBinary)
		finalImageData, err := sharpenAndCompressImage(combinedImageData)
		// finalImageData, err := resizeImage(combinedImageData)

		log.Println("size of Combined image- ", len(finalImageData))

		compressd_bytes, err := Compress(finalImageData)
		log.Println("size of compressd_bytes- ", len(compressd_bytes))

		photoBase64 := base64.StdEncoding.EncodeToString(compressd_bytes)
		log.Println("size of compressed base64 string: ", len(photoBase64))

		piData := data.PanNumber + "|" + data.CardType + "|" + data.NameOnCard + "|" + data.ParentName + "|" + data.ParentLabel + "|" + data.DateOfBirth
		log.Println("piData: ", piData)
		log.Println("photoBase64: ", photoBase64)

		bigIntValue := new(big.Int).SetBytes(compressd_bytes)
		log.Println("Big integer value:", bigIntValue)

		// If you want, you can also get a string representation (decimal or hex)
		log.Println("Decimal:", bigIntValue.String())
		log.Println("Hex:", bigIntValue.Text(16))


		//piData = "123"
		// encryptionKey := []byte("my-secret-key-12") // Replace with a securely generated key
		//encryptionKey := []byte{100, 55, 54, 51, 100, 52, 45, 53, 56, 54, 56, 45, 52, 57, 53, 51}

		base64Str := "SMgkSg8q/62WI0IZ8xCM2w=="

		// Decode the Base64 string
		decodedBytes, err := base64.StdEncoding.DecodeString(base64Str)
		fmt.Println(decodedBytes)

		nonce, encryptedPIData, err := encrypt([]byte(piData), decodedBytes)
		if err != nil {
			return "", fmt.Errorf("failed to encrypt PIData: %v", err)
		}

		cwtClaims := CombinedClaims{
			Issuer:     "VC-Issuer",
			Subject:    "Test Resident",
			Audience:   "VC-Holder",
			Expiration: uint64(time.Now().Add(time.Hour * 24).Unix()),
			CWTID:      []byte{1, 2, 3, 4},
			Custom: CustomClaims{
				PIData: base64.StdEncoding.EncodeToString(append(nonce, encryptedPIData...)), //base64.StdEncoding.EncodeToString(append(nonce, encryptedPIData...)),
				Photo:  compressd_bytes,                                                      // Photo binary encoded as base64
			},
		}

		log.Println("cwtClaims : ", cwtClaims)

		//Encode payload to CBOR
		cborPayload, err := cbor.Marshal(cwtClaims)
		if err != nil {
			log.Fatalf("Failed to CBOR encode payload: %v", err)
		}
		log.Println("Hex:", bigIntValue.Text(16))

		bigIntValueq := new(big.Int).SetBytes(cborPayload)

		log.Println("Big integer (decimal):", bigIntValueq.String())
		log.Println("Big integer (hex):", bigIntValueq.Text(16))

		log.Println("cborPayload : ", len(cborPayload))

		// Create a signing key
		key := []byte("my-secret-key-12345") // Replace with your secure key
		signingKey := jose.SigningKey{Algorithm: jose.HS256, Key: key}

		// Create a signer
		signer, err := jose.NewSigner(signingKey, nil)
		if err != nil {
			log.Fatalf("Failed to create signer: %v", err)
		}

		// Create CWT (sign CBOR payload)
		object, err := signer.Sign(cborPayload)
		if err != nil {
			log.Fatalf("Failed to sign payload: %v", err)
		}

		// Serialize the signed object
		compactSerialization, err := object.CompactSerialize()
		if err != nil {
			log.Fatalf("Failed to serialize signed object: %v", err)
		}

		//fmt.Println("CWT Token:", compactSerialization)

		// qrCode, err := qrcode.NewWithForcedVersion("CBOR"+compactSerialization, 40, qrcode.Medium)
		// if err != nil {
		//      return "", fmt.Errorf("failed to create QR code: %v", err)
		// }

		qrCode, err := qrcode.New("CBOR"+compactSerialization, qrcode.Low)
		if err != nil {
			return "", fmt.Errorf("failed to create QR code: %v", err)
		}

		//log.Println("qrcode value --", qrCode)

		qrCodeData, err := qrCode.PNG(100)
		if err != nil {
			return "", fmt.Errorf("failed to generate PNG QR code: %v", err)
		}

		qrBase64 := base64.StdEncoding.EncodeToString(qrCodeData)

		return qrBase64, nil
	}
}

func Decompress(compressedData []byte) ([]byte, error) {
	log.Println("Decompressing data")
	b := bytes.NewReader(compressedData)
	reader, err := zlib.NewReader(b)
	if err != nil {
		return nil, err
	}
	defer reader.Close()

	var outBuffer bytes.Buffer
	_, err = io.Copy(&outBuffer, reader)
	if err != nil {
		return nil, err
	}

	return outBuffer.Bytes(), nil
}

func ReadQRCode(base64Input string) *CombinedClaims {

	decodedImage, err := base64.StdEncoding.DecodeString(base64Input)
	if err != nil {
		log.Fatalf("Failed to Decode Image: %v", err.Error())
	}

	log.Println("decodedImage - ", decodedImage)

	// Step 2: Read the QR code data
	qrMatrix, err := qr.Decode(bytes.NewReader(decodedImage))
	if err != nil {
		log.Fatalf("Failed to decode QR code: %v", err)
	}

	qrContent := qrMatrix.Content

	if len(qrContent) >= 4 && qrContent[:4] == "CBOR" {
		base64Input = qrContent[4:] // Remove "CBOR" prefix
	}
	fmt.Println(base64Input)

	token, err := jose.ParseSigned(base64Input)
	if err != nil {
		log.Fatalf("Failed to parse CWT token: %v", err.Error())
	}
	key := []byte("my-secret-key-12345") // Replace with your secure key
	//encryptionKey := []byte{100, 55, 54, 51, 100, 52, 45, 53, 56, 54, 56, 45, 52, 57, 53, 51}
	// Verify the signature
	verifiedPayload, err := token.Verify(key)
	if err != nil {
		log.Fatalf("Failed to verify token: %v", err)
	}

	fmt.Println("verifiedPayload - ", verifiedPayload)

	// Decode CBOR payload
	var decodedPayload CombinedClaims
	err = cbor.Unmarshal(verifiedPayload, &decodedPayload)
	if err != nil {
		log.Fatalf("Failed to decode CBOR payload: %v", err)
	}

	//fmt.Println("Decoded Payload:", decodedPayload.Custom.PIData)

	encryptedPIData, err := base64.StdEncoding.DecodeString(decodedPayload.Custom.PIData)
	// encryptionKey := []byte("my-secret-key-12") // Replace with a securely generated key
	//encryptionKey = []byte{100, 55, 54, 51, 100, 52, 45, 53, 56, 54, 56, 45, 52, 57, 53, 51}

	base64Str := "SMgkSg8q/62WI0IZ8xCM2w=="

	// Decode the Base64 string
	decodedBytes, err := base64.StdEncoding.DecodeString(base64Str)
	//fmt.Println(decodedBytes)

	nonce := encryptedPIData[:12]
	ciphertext := encryptedPIData[12:]
	decryptedPIData, err := decrypt(ciphertext, nonce, decodedBytes)
	if err != nil {
		log.Fatalf("Failed to decrypt PIData: %v", err)
	}

	fmt.Println("Decrypted PIData:", string(decryptedPIData))

	decodedPayload.Custom.PIData = string(decryptedPIData)

	fmt.Println("PI Data - ", decodedPayload.Custom.PIData)

	decompressedPhoto, err := Decompress(decodedPayload.Custom.Photo)

	// Step 8: Set the decompressed photo back into the decodedData structure
	decodedPayload.Custom.Photo = decompressedPhoto

	return &decodedPayload

}

// Encrypt encrypts plaintext using AES-GCM with a given key
func encrypt(plaintext, key []byte) ([]byte, []byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, nil, err
	}

	nonce := make([]byte, 12) // GCM standard nonce size is 12 bytes
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, nil, err
	}

	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return nil, nil, err
	}

	ciphertext := aesGCM.Seal(nil, nonce, plaintext, nil)
	return nonce, ciphertext, nil
}

// Decrypt decrypts ciphertext using AES-GCM with a given key and nonce
func decrypt(ciphertext, nonce, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}

	plaintext, err := aesGCM.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, err
	}

	return plaintext, nil
}

// Decrypt with AES-GCM

func main() {
	app := fiber.New()

	app.Post("/generate-qr", func(c *fiber.Ctx) error {
		log.Println("Received request to generate QR code")
		var data VCClaims

		if err := c.BodyParser(&data); err != nil {
			return c.Status(fiber.StatusBadRequest).SendString("Invalid JSON")
		}

		var tempData string = data.RequestId + "," + data.PanNumber + "," + data.CardType + "," + data.NameOnCard + "," + data.ParentName + "," + data.ParentLabel + "," + data.DateOfBirth + "," + data.PhotoEncoding + "," + data.DateOfIncorporation + "," + data.Photo + "," + data.SignaturePhoto
		log.Println("Total length : ", len(tempData))
		log.Println("RequestId : ", len(data.RequestId))
		log.Println("PanNumber : ", len(data.PanNumber))
		log.Println("CardType : ", len(data.CardType))
		log.Println("NameOnCard : ", len(data.NameOnCard))
		log.Println("ParentName : ", len(data.ParentName))
		log.Println("ParentLabel : ", len(data.ParentLabel))
		log.Println("DateOfBirth : ", len(data.DateOfBirth))
		log.Println("PhotoEncoding : ", len(data.PhotoEncoding))
		log.Println("DateOfIncorporation : ", len(data.DateOfIncorporation))
		log.Println("Photo : ", len(data.Photo))
		log.Println("SignaturePhoto : ", len(data.SignaturePhoto))

		qrBase64, err := GenerateQRCode(data)
		if err != nil {
			return c.Status(fiber.StatusInternalServerError).SendString(fmt.Sprintf("Error: %v", err))
		}

		return c.JSON(fiber.Map{
			"qr_base64": qrBase64,
		})
	})

	app.Get("/generate-keypair", func(c *fiber.Ctx) error {

		pubkey, privkey := GenerateKeyPair()

		return c.JSON(fiber.Map{
			"Private Key": privkey,
			"Public Key":  pubkey,
		})
	})

	app.Post("/read-qr", func(c *fiber.Ctx) error {
		log.Println("Received request to read QR code")
		var input map[string]string

		if err := c.BodyParser(&input); err != nil {
			return c.Status(fiber.StatusBadRequest).SendString("Invalid JSON")
		}

		base64Input := input["qr_base64"]
		if base64Input == "" {
			return c.Status(fiber.StatusBadRequest).SendString("Missing 'qr_base64' field")
		}

		// Call the QR code reader function to decode and verify
		decodedData := ReadQRCode(base64Input)

		//log.Println("Decodeddata", decodedData)

		return c.JSON(fiber.Map{
			"decoded_data": decodedData,
		})
	})

	app.Listen(":3030")
}
